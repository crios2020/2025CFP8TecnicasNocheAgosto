//Clase ejecutiva, tiene el punto de entrada que se puede ejecutar (método main)
public class Main
{
    public static void main(String[] args) {
        System.out.println("Hola Mundo!");
        System.out.println("Versión de Java: "+System.getProperty("java.version"));
        
        /*
            POO Programación Orientada a Objetos
            
            Que es una clase? Una clase es todo lo que es sustantivo en el mundo real y representa 
            una generalización o molde para construir objetos o instancias de la clase.
            Las clases se suelen detectar en plural, pero se identifican en singular, con la primer letra en 
            mayúsculas.
            Ej: Alumno, Computadora, Silla, Profesor.
            
            Que es un atributo? Un atributo es un adjetivo que describe a la clase, pertenece a la clase,
            es una variable contenida dentro de una clase. y tiene un tipo de datos asociado.
            
            Que es un método? Es una acción que realiza la clase, se detecta como verbo. 
            es una función contenida en una clase, puede tener parámetros de entrada y 
            parámetros de salida.
            
            Que es un objetos? Es una instancia de la una clase, representa una situación en particular.
            Tiene un estado propio. El estado es el valor de los atributos.
            La clase define los atributos, y en los objetos se fija el estado.
            
            Que es la sobrecarga de métodos? Es cuando un método repite el nombre dentro de la clase,
            pero cambia la firma de parámetros de entrada.
            
        */
        
        //creamos el objeto auto1
        System.out.println("-- auto1 --");
        Auto auto1=new Auto();              //new Auto() llamo al constructor de la clase
        auto1.marca="Ford";
        auto1.modelo="Ka";
        auto1.color="Gris";
        auto1.acelerar();               //10
        auto1.acelerar();               //20
        auto1.acelerar();               //30
        auto1.frenar();                 //20
        auto1.acelerar(23);             //43
        //Imprimimos el estado del objeto
        System.out.println(auto1.marca+", "+auto1.modelo+", "+auto1.color+", "+auto1.velocidad);
        
        System.out.println("-- auto2 --");
        Auto auto2=new Auto();
        auto2.marca="Fiat";
        auto2.modelo="Idea";
        auto2.color="Rojo";
        
        for(int a=0; a<=50; a++) auto2.acelerar();
        
        System.out.println(auto2.marca+", "+auto2.modelo+", "+auto2.color+", "+auto2.velocidad);
        auto2.imprimirVelocidad();
        System.out.println(auto2.obtenerVelocidad());
        
        //método toString()
        System.out.println(auto2.toString());
        System.out.println(auto2);
        
        
        //TODO constructor
        
        
    }// end main
}// end class Auto

//Declaración de clase, Es una clase de negocio
class Auto {
    
    //Atributos
    String marca;
    String modelo;
    String color;
    int velocidad;
    
    //Métodos
    //un método void, no tiene devolución de valor.
    void acelerar(){
        //velocidad=velocidad+10
        velocidad+=10;
        if(velocidad>100)   velocidad=100;
    }
    
    //método sobrecargado
    void acelerar(int kilometros){
        velocidad+=kilometros;
        if(velocidad>100)   velocidad=100;
    }
    
    void frenar(){
        velocidad-=10;
        if(velocidad<0)     velocidad=0;
    }
    
    //método sin devolución
    void imprimirVelocidad(){
        System.out.println(velocidad);
    }
    
    //método con devolución de parámetro
    int obtenerVelocidad(){
        return velocidad;
    }
    
    //método toString
    public String toString(){
        return marca+", "+modelo+", "+color+", "+velocidad;
    }
    
}// end class Auto


