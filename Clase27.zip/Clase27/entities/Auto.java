package entities;

public class Auto {
    private String marca;
    private String modelo;
    private String color;
    private Radio radio;

    // public Auto(String marca, String modelo, String color, Radio radio) {
    //     this.marca = marca;
    //     this.modelo = modelo;
    //     this.color = color;
    //     this.radio = radio;
    // }

    public Auto(    String marca, 
                    String modelo, 
                    String color, 
                    String marcaRadio, 
                    int potencia) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.radio = new Radio(marcaRadio, potencia);
    }

    @Override
    public String toString() {
        return "Auto [marca=" + marca + ", modelo=" + modelo + ", color=" + color + ", radio=" + radio + "]";
    }
    public String getMarca() {
        return marca;
    }
    public void setMarca(String marca) {
        this.marca = marca;
    }
    public String getModelo() {
        return modelo;
    }
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    public String getColor() {
        return color;
    }
    public void setColor(String color) {
        this.color = color;
    }
    public Radio getRadio() {
        return radio;
    }
    public void setRadio(Radio radio) {
        this.radio = radio;
    }

    
}
