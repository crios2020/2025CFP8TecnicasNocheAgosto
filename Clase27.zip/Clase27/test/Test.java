package test;

import entities.Auto;
import entities.Radio;

public class Test {
    public static void main(String[] args) {
        System.out.println("-- radio1 --");
        Radio radio1=new Radio("Sony",2000);
        System.out.println(radio1);

        System.out.println("-- auto1 --");
        Auto auto1=new Auto(
                            "Ford", 
                            "Ka", 
                            "Azul", 
                            "Sony",
                            2000
                        );
        System.out.println(auto1);


        System.out.println("-- auto2 --");
        Auto auto2=new Auto("Fiat", 
                            "Uno", 
                            "Azul", 
                            "Sony",
                            2000);
        System.out.println(auto2);
        
        System.out.println("-- auto2 --");
        Auto auto3=new Auto("Citroen", 
                            "C3", 
                            "Rojo", 
                            "Sony",
                            2000);
        System.out.println((auto3));


    }
}
