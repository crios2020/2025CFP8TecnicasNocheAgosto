function cartel(){
    print("************************************************")
    print("*        Hola a todos !!!!                     *")
    print("************************************************")
}

//Función con parámetros de entrada
function cartel2(texto){
    print("************************************************")
    print(texto)
    print("************************************************") 
}

function sumar(nro1, nro2){
    resultado=nro1+nro2
    print(resultado)
}

//función con valor de retorno
function sumar2(nro1, nro2){
    return nro1+nro2
}