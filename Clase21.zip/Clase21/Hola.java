public class Hola {                 //Declaración de clase principal
    //La clase principal debe tener el mismo nombre que el archivo.java
    //EJ. class Hola{}      file Hola.java

    //Método main
    //Este método es el punto de entrada ejecutable del programa
    public static void main(String[] args) {
        System.out.println("Hola Mundo");
        
        //Variables
        // Lenguajes de tipado fuerte: Java, C++, C#, Pascal, Visual Basic, Typescript
        // Lenguajes de tipado debil:  Javascript, Python, PHP 
        
        //Tipo de datos entero
        //declaración de Variables
        
        int a;                          //declaración de variable a
        a=2;                            //asignación de valor
        
        int b=4;                        //declaración y asignación de valor a una variable
        
        int c=5, d=65, e=39, f=23, g=26;
            //declaración y asignación a multiples Variables
        
        //Impresión de variable
        System.out.println(a);
        System.out.println("Variable a: "+a);
        
        //Variables String
        String texto="Hola a todos";
        System.out.println(texto);
        
        //Variables boolean
        boolean bo=true;
        bo=false;
        System.out.println(bo);
        
        //Variables char
        char ch=65;
        System.out.println(ch);
        ch+=32;
        System.out.println(ch);
        ch='h';
        System.out.println(ch);
        
        //Variables float   32 bits
        float fl=3.25f;
        System.out.println(fl);
        
        //Variables double 64 bits
        double dl=3.25;
        System.out.println(dl);
        
        
        
    } //end método main
}//end class Main

