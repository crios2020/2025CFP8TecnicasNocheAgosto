package entities;

public class ClientePersona {
    
    private int nro;
    private String nombre;
    private int edad;
    private Cuenta cuenta;
    public ClientePersona(int nro, String nombre, int edad, Cuenta cuenta) {
        this.nro = nro;
        this.nombre = nombre;
        this.edad = edad;
        this.cuenta = cuenta;
    }
    @Override
    public String toString() {
        return "Cliente [nro=" + nro + ", nombre=" + nombre + ", edad=" + edad + ", cuenta=" + cuenta + "]";
    }
    public Cuenta getCuenta() {
        return cuenta;
    }

    
}
