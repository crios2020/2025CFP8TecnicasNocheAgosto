package test;

import entities.ClienteEmpresa;
import entities.ClientePersona;
import entities.Cuenta;

public class TestRelaciones {
    public static void main(String[] args) {
        
        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1, "Args");
        cuenta1.depositar(250000);
        cuenta1.depositar(650000);
        cuenta1.debitar(320000);
        System.out.println(cuenta1);

        System.out.println("-- clientePersona1 --");
        ClientePersona clientePersona1=new ClientePersona(
                                            1, 
                                            "Juan Perez", 
                                            40, 
                                            new Cuenta(2, "arg$")
                                        );
        clientePersona1.getCuenta().depositar(600000);
        clientePersona1.getCuenta().debitar(240000);                                
        System.out.println(clientePersona1);

        System.out.println("-- clienteEmpresa1 --");
        ClienteEmpresa clienteEmpresa1=new ClienteEmpresa(
                                                        1, 
                                                        "Todo Limpio SRL", 
                                                        "Lima 222"
                                                    );
        
        clienteEmpresa1.getCuentas().add(new Cuenta(11, "arg$"));           //0
        clienteEmpresa1.getCuentas().add(new Cuenta(12, "Reales"));         //1
        clienteEmpresa1.getCuentas().add(new Cuenta(13, "U$S"));            //2

        clienteEmpresa1.getCuentas().get(0).depositar(850000);
        clienteEmpresa1.getCuentas().get(0).depositar(725000);
        clienteEmpresa1.getCuentas().get(0).debitar(132000);

        clienteEmpresa1.getCuentas().get(1).depositar(230000);

        clienteEmpresa1.getCuentas().get(2).depositar(12000);
                                        
        System.out.println(clienteEmpresa1);                                            
    }
}
