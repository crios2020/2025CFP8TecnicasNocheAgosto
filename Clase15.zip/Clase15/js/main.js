function cartel(){
    print("************************************************")
    print("*        Hola a todos !!!!                     *")
    print("************************************************")
}

//Función con parámetros de entrada
function cartel2(texto){
    print("************************************************")
    print(texto)
    print("************************************************") 
}

function sumar(nro1, nro2){
    resultado=nro1+nro2
    print(resultado)
}

//función con valor de retorno
function sumar2(nro1, nro2){
    return nro1+nro2
}

//Función Calcular
function calcular(operacion, numero1, numero2){
    resultado=0
    switch(operacion){
        case 'sumar':       resultado=numero1+numero2;          break
        case 'restar':      resultado=numero1-numero2;          break
        case 'multiplica':  resultado=numero1*numero2;          break
        case 'dividir':     
                        if(numero2!=0)         resultado=numero1/numero2   
                        else                resultado='Error / 0'
    }
    return resultado
}