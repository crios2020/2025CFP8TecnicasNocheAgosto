package entities;

public class Computadora {
    private String nombre;
    private String ip;
    private String procesador;
    private String memoria;
    private String disco;

    public Computadora(String nombre, String ip, String procesador, String memoria, String disco) {
        this.nombre = nombre;
        this.ip = ip;
        this.procesador = procesador;
        this.memoria = memoria;
        this.disco = disco;
    }

    @Override
    public String toString() {
        return "Computadora [nombre=" + nombre + ", ip=" + ip + ", procesador=" + procesador + ", memoria=" + memoria
                + ", disco=" + disco + "]";
    }

    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getIp() {
        return ip;
    }
    public void setIp(String ip) {
        this.ip = ip;
    }
    public String getProcesador() {
        return procesador;
    }
    public void setProcesador(String procesador) {
        this.procesador = procesador;
    }
    public String getMemoria() {
        return memoria;
    }
    public void setMemoria(String memoria) {
        this.memoria = memoria;
    }
    public String getDisco() {
        return disco;
    }
    public void setDisco(String disco) {
        this.disco = disco;
    }
}
