public class Clase25{
    public static void main(String[] args) {
        System.out.println("-- Clase 25 --");
    }
}