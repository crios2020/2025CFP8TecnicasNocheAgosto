package test;

import entities.Computadora;

public class TestComputadora {
    public static void main(String[] args) {
        //Objetos de prueba de clase Computadora

        System.out.println("-- computadora1 --");
        Computadora computadora1=new Computadora(
                                                "computadora1", 
                                                "192.168.0.101", 
                                                "I5", 
                                                "16GB", 
                                                "SSD 512GB"
                                            );
        System.out.println(computadora1);

    }
}
