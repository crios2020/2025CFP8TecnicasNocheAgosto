package test;

import java.text.DecimalFormat;

import entities.Circulo;
import entities.Rectangulo;
import entities.Triangulo;
// import entities.*;

public class TestFigura {
    public static void main(String[] args) {

        DecimalFormat df=new DecimalFormat("0.00");

        System.out.println("-- rectangulo1 --");
        Rectangulo rectangulo1=new Rectangulo(25, 30);
        System.out.println(rectangulo1);
        System.out.println("Perimetro: "+df.format(rectangulo1.getPerimetro()));
        System.out.println("Superficie: "+df.format(rectangulo1.getSuperficie()));


        System.out.println("-- triangulo1 --");
        Triangulo triangulo1=new Triangulo(50, 40);
        System.out.println(triangulo1);
        System.out.println("Perimetro: "+df.format(triangulo1.getPerimetro()));
        System.out.println("Superficie: "+df.format(triangulo1.getSuperficie()));

        System.out.println("-- circulo1 --");
        Circulo circulo1=new Circulo(50);
        System.out.println(circulo1);
        System.out.println("Perimetro: "+df.format(circulo1.getPerimetro()));
        System.out.println("Superficie: "+df.format(circulo1.getSuperficie()));

    }
}
