class Rectangulo{
    double lado1;
    double lado2;
    
    double getPerimetro(){
        return (lado1+lado2)*2;
    }
    
    double getSuperficie(){
        return lado1*lado2;
    }
}

class Triangulo{
    double base;
    double altura;
    
    double getPerimetro(){
        return base+altura+Math.hypot(base, altura);
    }
    
    double getSuperficie(){
        return base*altura/2;
    }
}

class Circulo{
    double radio;
    
    double getPerimetro(){
        return Math.PI*radio*2;
    }
    
    double getSuperficie(){
        return Math.PI*radio*radio;
    }
}

public class Main
{
    public static void main(String[] args) {
        System.out.println("Figuras Geometricas");
        System.out.println("-- rectangulo1 --");
        Rectangulo rectangulo1=new Rectangulo();
        rectangulo1.lado1=50;
        rectangulo1.lado2=40;
        System.out.println("perimetro: "+rectangulo1.getPerimetro());
        System.out.println("superficie: "+rectangulo1.getSuperficie());
        
        System.out.println("-- triangulo1 --");
        Triangulo triangulo1=new Triangulo();
        triangulo1.base=50;
        triangulo1.altura=40;
        System.out.println("perimetro: "+triangulo1.getPerimetro());
        System.out.println("superficie: "+triangulo1.getSuperficie());
        
        System.out.println("-- circulo1 --");
        Circulo circulo1=new Circulo();
        circulo1.radio=100;
        System.out.println("perimetro: "+circulo1.getPerimetro());
        System.out.println("superficie: "+circulo1.getSuperficie());
    }
}
